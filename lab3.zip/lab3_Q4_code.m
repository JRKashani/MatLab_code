clc;
h = input("Please enter the height of the building: ");
g =9.8;
t = sqrt(h*2/g);
fprintf("The time it will take a rock free falling from the roof of the building to hit the ground is %.2f seconds.\n", t);